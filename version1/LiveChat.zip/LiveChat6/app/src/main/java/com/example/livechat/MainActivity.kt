package com.example.livechat

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val notificationPermissionCode = 101
    private val TAG = "LiveChatMain"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ── Permission notifications (Android 13+) ──────────────
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    notificationPermissionCode
                )
            }
        }

        // ── Canal de notification (Android 8+) ──────────────────
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "livechat_channel",
                "LiveChat",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications des messages LiveChat"
                enableLights(true)
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }

        // ── Configuration WebView ────────────────────────────────
        webView = findViewById(R.id.webview)
        webView.apply {
            settings.apply {
                javaScriptEnabled  = true
                domStorageEnabled  = true
                cacheMode          = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls  = false
                displayZoomControls  = false
            }
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            webViewClient = WebViewClient()
            addJavascriptInterface(AndroidBridge(this@MainActivity), "AndroidBridge")
        }

        webView.loadUrl("file:///android_asset/index.html")

        // ── Bouton retour ────────────────────────────────────────
        onBackPressedDispatcher.addCallback(
            this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (webView.canGoBack()) webView.goBack()
                    else finish()
                }
            }
        )
    }

    // ── Cycle de vie → AppState + effacement notification ───────
    override fun onResume() {
        super.onResume()
        webView.onResume()
        AppState.isAppInForeground = true

        // Effacer la notification groupée quand l'user ouvre l'app
        getSystemService(NotificationManager::class.java)
            ?.cancel(MyFirebaseMessagingService.NOTIFICATION_ID)

        // Vider les données groupées (nouvelle session)
        MyFirebaseMessagingService.clearAllData()

        Log.d(TAG, "▶️ App au premier plan")
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
        AppState.isAppInForeground = false
        Log.d(TAG, "⏸️ App en arrière-plan")
    }

    override fun onDestroy() {
        super.onDestroy()
        AppState.isAppInForeground = false
    }
}