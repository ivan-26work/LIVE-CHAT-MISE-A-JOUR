package com.example.livechat

object AppState {
    var isAppInForeground = false
}