package com.example.livechat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Color
import android.media.RingtoneManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        const val NOTIFICATION_ID = 1001
        private val TAG = "FCMService"

        private val groupedData = mutableMapOf<String, SenderData>()
        private val lock = Any()
        private var lastSoundTime = 0L

        fun clearAllData() {
            synchronized(lock) { groupedData.clear() }
        }

        data class SenderData(
            val name: String,
            val messages: MutableList<Pair<String, Long>> = mutableListOf()
        )
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d(TAG, "📩 Message FCM reçu")

        if (AppState.isAppInForeground) {
            Log.d(TAG, "📱 App au premier plan → ignoré")
            return
        }

        val data      = remoteMessage.data
        val userId    = data["userId"]      ?: return
        val userName  = data["userName"]    ?: "Utilisateur"
        val msgText   = data["messageText"] ?: return
        val timestamp = System.currentTimeMillis()

        synchronized(lock) {
            val sender = groupedData.getOrPut(userId) { SenderData(userName) }
            sender.messages.add(Pair(msgText, timestamp))
        }

        val now = SystemClock.elapsedRealtime()
        val playSound = (now - lastSoundTime) > 10_000L
        if (playSound) lastSoundTime = now

        showNotification(playSound)
    }

    private fun showNotification(playSound: Boolean) {
        val snapshot = synchronized(lock) { groupedData.toMap() }
        if (snapshot.isEmpty()) return

        var totalMessages = 0
        snapshot.values.forEach { totalMessages += it.messages.size }
        val totalSenders = snapshot.size

        // ── Intent ──────────────────────────────────────────────
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, NOTIFICATION_ID, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                        PendingIntent.FLAG_IMMUTABLE else 0
        )

        // ── Titre (replié) ───────────────────────────────────────
        // "LiveChat · 3 messages" ou "LiveChat · 5 messages de 2 personnes"
        val title = if (totalSenders == 1) {
            "LiveChat · $totalMessages message${if (totalMessages > 1) "s" else ""}"
        } else {
            "LiveChat · $totalMessages messages de $totalSenders personnes"
        }

        // ── Contenu replié (1 ligne) ─────────────────────────────
        val collapsedText = if (totalSenders == 1 && totalMessages == 1) {
            val sender = snapshot.values.first()
            "${sender.name} : ${sender.messages.first().first}"
        } else if (totalSenders == 1) {
            val sender = snapshot.values.first()
            "${sender.name} : ${sender.messages.last().first}"
        } else {
            val names = snapshot.values.joinToString(", ") { it.name }
            "$names · $totalMessages messages"
        }

        // ── InboxStyle (déplié) ──────────────────────────────────
        // ✅ FIX 1 : setBigContentTitle affiche les noms, pas "LiveChat" en double
        val sendersLabel = if (totalSenders == 1)
            snapshot.values.first().name
        else
            snapshot.values.joinToString(", ") { it.name }

        val inboxStyle = NotificationCompat.InboxStyle()
            .setBigContentTitle(sendersLabel)  // ✅ noms seulement, pas "LiveChat"

        snapshot.forEach { (_, senderData) ->
            val lastMsgTime = senderData.messages.lastOrNull()?.second
                ?: System.currentTimeMillis()
            val timeAgo = getTimeAgo(lastMsgTime)

            // Ligne nom + temps
            if (totalSenders > 1) {
                inboxStyle.addLine("${senderData.name}  ·  $timeAgo")
            }

            // Messages indentés (max 3)
            val msgs = senderData.messages
            val displayMsgs = if (msgs.size > 3) {
                val hidden = msgs.size - 3
                listOf(Pair("  +$hidden autres messages", 0L)) +
                        msgs.takeLast(3).map { Pair("  ${it.first}", it.second) }
            } else {
                msgs.map { Pair("  ${it.first}", it.second) }
            }

            displayMsgs.forEach { (text, _) ->
                val truncated = if (text.length > 55) text.take(55) + "…" else text
                inboxStyle.addLine(truncated)
            }

            if (totalSenders > 1) inboxStyle.addLine("")
        }

        // ── Construction ─────────────────────────────────────────
        val soundUri = if (playSound)
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        else null

        val builder = NotificationCompat.Builder(this, "livechat_channel")
            .setSmallIcon(R.drawable.ic_notification)  // ✅ FIX 2 : icône monochrome correcte
            .setColor(Color.parseColor("#3b8bff"))
            .setContentTitle(title)
            .setContentText(collapsedText)
            .setStyle(inboxStyle)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setNumber(totalMessages)
            .setOnlyAlertOnce(!playSound)

        if (playSound && soundUri != null) {
            builder.setSound(soundUri)
            builder.setVibrate(longArrayOf(0, 200, 100, 200))
        } else {
            builder.setSound(null)
            builder.setVibrate(null)
        }

        try {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, builder.build())
            Log.d(TAG, "✅ Notification — $totalMessages msg(s) de $totalSenders expéditeur(s)")
        } catch (e: SecurityException) {
            Log.e(TAG, "❌ Permission refusée: ${e.message}")
        }
    }

    private fun getTimeAgo(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        return when {
            diff < 60_000L     -> "à l'instant"
            diff < 3_600_000L  -> "il y a ${diff / 60_000L} min"
            diff < 86_400_000L -> "il y a ${diff / 3_600_000L}h"
            else               -> "hier"
        }
    }

    override fun onNewToken(token: String) {
        Log.d(TAG, "🔄 Nouveau token FCM")
        val user = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseDatabase.getInstance()
            .getReference("fcmTokens")
            .child(user.uid)
            .child(token)
            .setValue(true)
            .addOnSuccessListener { Log.d(TAG, "✅ Token enregistré") }
            .addOnFailureListener { e -> Log.e(TAG, "❌ Erreur: ${e.message}") }
    }
}