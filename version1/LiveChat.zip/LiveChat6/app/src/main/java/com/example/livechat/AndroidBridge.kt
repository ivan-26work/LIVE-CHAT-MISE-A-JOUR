package com.example.livechat

import android.content.Context
import android.util.Log
import android.webkit.JavascriptInterface
import com.google.firebase.messaging.FirebaseMessaging

class AndroidBridge(private val context: Context) {

    private val TAG = "AndroidBridge"

    @JavascriptInterface
    fun onUserLoggedIn(userId: String) {
        Log.d(TAG, "📲 onUserLoggedIn — userId: $userId")

        if (userId.isBlank()) {
            Log.e(TAG, "❌ userId vide, abandon")
            return
        }

        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                Log.d(TAG, "✅ Token FCM obtenu: $token")
                saveTokenToDatabase(userId, token)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "❌ Erreur token FCM: ${e.message}")
            }
    }

    private fun saveTokenToDatabase(userId: String, token: String) {
        val db = com.google.firebase.database.FirebaseDatabase.getInstance()
        db.getReference("fcmTokens")
            .child(userId)
            .child(token)
            .setValue(true)
            .addOnSuccessListener {
                Log.d(TAG, "✅ Token enregistré dans Firebase !")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "❌ Erreur Firebase: ${e.message}")
            }
    }
}