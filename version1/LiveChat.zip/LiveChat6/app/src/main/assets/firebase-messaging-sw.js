package com.example.livechat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.net.URL

class MyFirebaseMessagingService : FirebaseMessagingService() {

    private val TAG = "FCMService"
    private val CHANNEL_ID = "livechat_channel"
    private val CHANNEL_NAME = "LiveChat Messages"
    private val GROUP_KEY = "livechat_group"

    // ─────────────────────────────────────────
    // MESSAGE REÇU (app ouverte OU fermée)
    // ─────────────────────────────────────────
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d(TAG, "📩 Message reçu de: ${remoteMessage.from}")

        // Récupérer les données personnalisées
        val data = remoteMessage.data
        val title = remoteMessage.notification?.title
            ?: data["title"]
            ?: "LiveChat"

        val body = remoteMessage.notification?.body
            ?: data["body"]
            ?: "Nouveau message"

        val userId = data["userId"] ?: "unknown"
        val userName = data["userName"] ?: "Utilisateur"
        val profileImageUrl = data["profileImage"]

        Log.d(TAG, "📬 Titre: $title | Corps: $body | User: $userName")

        showNotification(title, body, userId, userName, profileImageUrl)
    }

    // ─────────────────────────────────────────
    // AFFICHER LA NOTIFICATION (AMÉLIORÉE)
    // ─────────────────────────────────────────
    private fun showNotification(
        title: String,
        body: String,
        userId: String,
        userName: String,
        profileImageUrl: String?
    ) {
        val notifId = System.currentTimeMillis().toInt()

        // Intent → ouvre MainActivity au clic
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("openChatUserId", userId)
            putExtra("openChatUserName", userName)
        }

        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_ONE_SHOT
        }

        val pendingIntent = PendingIntent.getActivity(
            this, notifId, intent, pendingIntentFlags
        )

        // Intent pour "Marquer comme lu"
        val markAsReadIntent = Intent(this, NotificationActionReceiver::class.java).apply {
            action = "MARK_AS_READ"
            putExtra("userId", userId)
            putExtra("conversationId", userId)
        }

        val markAsReadPendingIntent = PendingIntent.getBroadcast(
            this, userId.hashCode(), markAsReadIntent, pendingIntentFlags
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        // Créer le canal
        createNotificationChannel(soundUri)

        // Construire la notification
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 200, 100, 200))
            .setContentIntent(pendingIntent)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)

        // Ajouter la photo de profil si disponible
        if (profileImageUrl != null && profileImageUrl.isNotEmpty()) {
            try {
                val url = URL(profileImageUrl)
                val bitmap = BitmapFactory.decodeStream(url.openStream())
                builder.setLargeIcon(bitmap)
            } catch (e: Exception) {
                Log.e(TAG, "❌ Erreur chargement image: ${e.message}")
            }
        }

        // Ajouter le bouton "Marquer comme lu"
        builder.addAction(
            NotificationCompat.Action.Builder(
                android.R.drawable.ic_menu_check,
                "✓ Marquer comme lu",
                markAsReadPendingIntent
            ).build()
        )

        // Ajouter le style "Message" pour Android 7+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setStyle(
                NotificationCompat.MessagingStyle("Moi")
                    .addMessage(body, System.currentTimeMillis(), userName)
            )
        }

        // Groupement des notifications par utilisateur
        builder.setGroup(GROUP_KEY)
        builder.setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY)

        // Notification de résumé (si plusieurs messages du même user)
        val summaryNotifId = userId.hashCode()
        val existingSummary = NotificationManagerCompat.from(this).activeNotifications.find { it.id == summaryNotifId }

        if (existingSummary != null) {
            // Mise à jour du résumé
            val summaryBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("$userName a envoyé plusieurs messages")
                .setContentText("Appuyez pour voir la conversation")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setGroup(GROUP_KEY)
                .setGroupSummary(true)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            NotificationManagerCompat.from(this).notify(summaryNotifId, summaryBuilder.build())
        }

        // Afficher la notification
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(notifId, builder.build())

        Log.d(TAG, "✅ Notification affichée pour $userName")
    }

    // ─────────────────────────────────────────
    // CANAL DE NOTIFICATION (Android 8+)
    // ─────────────────────────────────────────
    private fun createNotificationChannel(soundUri: android.net.Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(CHANNEL_ID) != null) return

            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications des messages LiveChat"
                enableLights(true)
                lightColor = android.graphics.Color.parseColor("#3b8bff")
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 200)
                setSound(
                    soundUri,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
            manager.createNotificationChannel(channel)
            Log.d(TAG, "✅ Canal créé")
        }
    }

    // ─────────────────────────────────────────
    // TOKEN RAFRAÎCHI → RE-ENREGISTRER
    // ─────────────────────────────────────────
    override fun onNewToken(token: String) {
        Log.d(TAG, "🔄 Nouveau token: $token")
        val user = FirebaseAuth.getInstance().currentUser
        if (user != null) {
            FirebaseDatabase.getInstance()
                .getReference("fcmTokens")
                .child(user.uid)
                .child(token)
                .setValue(true)
                .addOnSuccessListener {
                    Log.d(TAG, "✅ Nouveau token enregistré")
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "❌ Erreur: ${e.message}")
                }
        }
    }
}