// ==================== FIREBASE CONFIG ====================
const firebaseConfig = {
    apiKey: "AIzaSyB2ZhldZcUH0HZHJxe-21EiXVMiPKFSqyg",
    authDomain: "livechat-4dd07.firebaseapp.com",
    databaseURL: "https://livechat-4dd07-default-rtdb.firebaseio.com/",
    projectId: "livechat-4dd07",
    storageBucket: "livechat-4dd07.firebasestorage.app",
    messagingSenderId: "276812426291",
    appId: "1:276812426291:web:c4688a1ec5c06161d20746"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

// ==================== SERVICE ACCOUNT FCM ====================
const SA = {
    project_id: "livechat-4dd07",
    private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDVIJCfHP+DGv6S\nufBJX8MyZZ9v9hqWw3bwV6wd2S+aNoY/VrBJbeSeVAiTvpat1FkUKkoiAN5gmIpe\nx3ZTQf6tICFipwbuuJtbfcu2SHoWnlGI972NEgjAxabpTPgBROK5deOEgMjBbcA/\nObCrwVjD/Kg3dqKA/jeZqRtZyEdnn6+93/qCYX025BLidy9s9TvSc/SKECheFYg8\nY8HGaZ+6qlRUav/daDbNVZ15lWi9Cam5oir43OQRIQ6DFeXdhY1P2UzkSdkmFUP3\nzqmNc29M5gZOY677ZlsBRM7jHWj9iKsxGx+teiy5xXT7Z6FjjviS09hkCVsjn+c0\nJaX6deq/AgMBAAECggEAaUwEh8gw6RpeKinZcLbyXqTcp9lEe7YovkfijoCuRxen\nLgXrZOv5ZswHzM797PYb6J2YMMKTG9BhlMAhUrMpW2mjdPUmtKzafNJi4jVetGwV\nxoD30onVb0B33Y4cfawGBDEdbmqeRQqvT8113vXQoEvk5DolwWtYFv/4tlwAA054\nB0qATd9pBfk868tpCWKGi0cW9EvTOFD2lnzUaP3iNp5EPul3X8wAsNsVt7XVdpUu\nyJ0uLfpyBqd8YU3yR0InO02XVfbMBeB42LEy+o5Bs8RqfwePKWAoU9frWScfcJmz\n8YDdXen/Hrk90ogbCv/q98f4gUgHFw06/dkX5vmpAQKBgQDvvVTb6T2mMT1ej5R/\nhh769hEJxpkugDMiNxNz3hAMGXUIrMNTvy6AXcD5Fz5PzLVJqcDVLx6sVe6YEcpb\n2VtYuFJ89YPRCm4/ylYhhExW3s2zWpjZLqRmk6LQZOE55kFUPdwg8cUfa5vv+k+4\nA+Qezbk97pvmyoQXjnWO/Ld6gQKBgQDjlSezRDRJNejXh9DiIeagxD5G8tlsBINt\nl2t+vyG5ezzxKktEuXrJOPUWVxG90JCMMmpcojrimENFdNeqtRsTonRgoWimVy7x\n016d8DTPmLOSOzXEY/rkDd535QmqYIGY6Ush4PWJNUUl4HLYlGs+h+zMr5ET3bw7\nFgtg7EpFPwKBgQDrsoirbDRgICjlvuOQPJxYv3Mg2U/gl8mt6dgGIlxEiQK29KNU\nwrFFIueF/YQVkHzrXylmbl0JsbJRb6wzgQ59uzneAMMH0elybcsgSKGFBqfVnUyI\nuYKIFr4LhCKqeeXgnLC+8vOKYJF+7elSUQEGB9wHN3+u94vGXRjW6z64AQKBgQCe\nRt68e2PNwtN0Cj4I90DZcIJLf5wc1qq9LkERfkYrJH2G0D5WxpSRm65AYj+xfnr5\nNhro398KNpEanh9b1ubE6gf8KGWKwjmg77rvJt7jvjStL8a+FjaoIsklI0Jsnv+i\n5CVfo3/AdC7qH8ZfwCEx9QCIflXsthqyESvKtasVqwKBgETYm79luC37zESkJnkY\nH3nPZ4S0rJgmj8CL1jgdfvsOaYqN3VpOaPhFoiHJ6XarAOhVP6Oy+80OF7bXTBed\nzh8dmUJ3OTZrd8m4xG2WscdKHAfpa9R/3WC4bcMr/Lxnb6W7pwHoNId0OdIw3P5z\nLQ1w65IS4zJUeO5FikfARAxC\n-----END PRIVATE KEY-----\n",
    client_email: "firebase-adminsdk-fbsvc@livechat-4dd07.iam.gserviceaccount.com",
    token_uri: "https://oauth2.googleapis.com/token"
};

let _fcmToken = null, _fcmExpiry = 0;

async function getAccessToken() {
    if (_fcmToken && Date.now() < _fcmExpiry - 300000) return _fcmToken;
    const b64 = s => btoa(unescape(encodeURIComponent(s)))
        .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const now = Math.floor(Date.now() / 1000);
    const hdr = b64(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
    const body = b64(JSON.stringify({
        iss: SA.client_email, sub: SA.client_email,
        aud: SA.token_uri, iat: now, exp: now + 3600,
        scope: 'https://www.googleapis.com/auth/firebase.messaging'
    }));
    const pem = SA.private_key
        .replace(/-----BEGIN PRIVATE KEY-----/, '')
        .replace(/-----END PRIVATE KEY-----/, '')
        .replace(/\n/g, '');
    const der = Uint8Array.from(atob(pem), c => c.charCodeAt(0));
    const key = await crypto.subtle.importKey(
        'pkcs8', der.buffer,
        { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']
    );
    const sig = await crypto.subtle.sign(
        'RSASSA-PKCS1-v1_5', key,
        new TextEncoder().encode(`${hdr}.${body}`)
    );
    const signature = btoa(String.fromCharCode(...new Uint8Array(sig)))
        .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const res = await fetch(SA.token_uri, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${hdr}.${body}.${signature}`
    });
    const d = await res.json();
    _fcmToken = d.access_token;
    _fcmExpiry = Date.now() + d.expires_in * 1000;
    return _fcmToken;
}

// ==================== NOTIFICATIONS PUSH ====================
async function sendPush(targetUid, messageText) {
    try {
        const snap = await db.ref(`fcmTokens/${targetUid}`).once('value');
        const tokens = snap.val();
        if (!tokens) return;
        const senderName = me.displayName || (me.email ? me.email.split('@')[0] : 'Utilisateur');
        const token = await getAccessToken();
        for (const fcmToken of Object.keys(tokens)) {
            await fetch(`https://fcm.googleapis.com/v1/projects/${SA.project_id}/messages:send`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: {
                        token: fcmToken,
                        data: {
                            userId: me.uid,
                            userName: senderName,
                            messageText: messageText.length > 200 ? messageText.slice(0, 200) + '…' : messageText
                        },
                        android: { priority: 'high' }
                    }
                })
            });
        }
    } catch (e) { console.error('Push error:', e); }
}

// ==================== ÉTAT GLOBAL ====================
let me = null;
let meSettings = { findable: true, hidePresence: false, disableReadReceipt: false, disableTyping: false };
let allUsers = {};
let discsMap = {};
let convListenerCb = null;
let msgsRef = null;
let onlineRef = null;
let typingRef = null;
let typingTimer = null;
let currentConvId = null;
let currentOtherUid = null;
let typingListeners = {};
let pendingDeleteConvId = null;
let lastReadListener = null;

// ==================== CACHE LOCAL ====================
function saveDiscsToCache() {
    localStorage.setItem('livechat_discsMap', JSON.stringify(discsMap));
}
function saveUsersToCache() {
    localStorage.setItem('livechat_allUsers', JSON.stringify(allUsers));
}
function loadCache() {
    const savedDiscs = localStorage.getItem('livechat_discsMap');
    if (savedDiscs) {
        discsMap = JSON.parse(savedDiscs);
        renderDiscs();
    }
    const savedUsers = localStorage.getItem('livechat_allUsers');
    if (savedUsers) {
        allUsers = JSON.parse(savedUsers);
    }
}

// ==================== CHARGEMENT OBLIGATOIRE DU PROFIL ====================
async function loadUserProfile() {
    if (!me) return;
    try {
        const snap = await db.ref(`users/${me.uid}`).once('value');
        const userData = snap.val();
        if (userData) {
            me.displayName = userData.username || '';
            me.email = userData.email || '';
            localStorage.setItem('livechat_username', me.displayName);
            localStorage.setItem('livechat_email', me.email);
            if (userData.photoURL) localStorage.setItem('livechat_photoURL', userData.photoURL);

            const usernameInput = document.getElementById('usernameInput');
            const userEmailSpan = document.getElementById('userEmail');
            const avatarInitial = document.getElementById('avatarInitial');
            if (usernameInput) usernameInput.value = me.displayName;
            if (userEmailSpan) userEmailSpan.textContent = me.email;
            if (avatarInitial) avatarInitial.textContent = (me.displayName || me.email || '?').charAt(0).toUpperCase();

            const avatarBtn = document.getElementById('avatarBtn');
            if (avatarBtn && userData.photoURL) {
                avatarBtn.innerHTML = `<img src="${userData.photoURL}" style="width:100%; height:100%; object-fit:cover; border-radius:50%;">`;
            }
        }
    } catch (err) {
        console.error("Erreur chargement profil:", err);
    }
}

// ==================== BARRE FOOTER ====================
let footerTempTimer = null;
let lastTempSenderId = null;
let volumePercent = 50;
let vibrationPercent = 50;

function loadSoundSettings() {
    const savedVolume = localStorage.getItem('volumePercent');
    const savedVibration = localStorage.getItem('vibrationPercent');
    if (savedVolume !== null) volumePercent = parseInt(savedVolume);
    if (savedVibration !== null) vibrationPercent = parseInt(savedVibration);
    const volumeSlider = document.getElementById('volumeSlider');
    const vibrationSlider = document.getElementById('vibrationSlider');
    const volumeValue = document.getElementById('volumeValue');
    const vibrationValue = document.getElementById('vibrationValue');
    if (volumeSlider) volumeSlider.value = volumePercent;
    if (vibrationSlider) vibrationSlider.value = vibrationPercent;
    if (volumeValue) volumeValue.textContent = volumePercent + '%';
    if (vibrationValue) vibrationValue.textContent = vibrationPercent + '%';
}
function saveVolume(value) {
    volumePercent = value;
    localStorage.setItem('volumePercent', value);
    const volumeValue = document.getElementById('volumeValue');
    if (volumeValue) volumeValue.textContent = value + '%';
}
function saveVibration(value) {
    vibrationPercent = value;
    localStorage.setItem('vibrationPercent', value);
    const vibrationValue = document.getElementById('vibrationValue');
    if (vibrationValue) vibrationValue.textContent = value + '%';
}
function playNotifSound() {
    if (volumePercent === 0) return;
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.frequency.value = 880;
        gainNode.gain.value = volumePercent / 100;
        oscillator.start();
        gainNode.gain.exponentialRampToValueAtTime(0.00001, audioCtx.currentTime + 0.5);
        oscillator.stop(audioCtx.currentTime + 0.5);
    } catch(e) { console.log("Audio non supporté"); }
}
function vibrate() {
    if (vibrationPercent === 0) return;
    if (navigator.vibrate) {
        const duration = Math.floor(200 * (vibrationPercent / 100));
        navigator.vibrate(duration);
    }
}
function getCurrentTime() {
    const now = new Date();
    return now.toLocaleTimeString('fr-FR', { hour12: false });
}
let barreClockInterval = null;
function startBarreClock() {
    if (barreClockInterval) clearInterval(barreClockInterval);
    const update = () => {
        const clockElement = document.getElementById('footerClock');
        const footerBar = document.getElementById('footerBar');
        if (clockElement && footerBar && !footerBar.classList.contains('temp-mode')) {
            clockElement.textContent = getCurrentTime();
        }
    };
    update();
    barreClockInterval = setInterval(update, 1000);
}
function updateFooterTotalBadge() {
    let total = 0;
    for (let convId in discsMap) total += discsMap[convId].unread || 0;
    const badgeEl = document.getElementById('footerBadge');
    if (badgeEl) {
        if (total === 0) badgeEl.style.display = 'none';
        else {
            badgeEl.style.display = 'flex';
            badgeEl.textContent = total;
        }
    }
}
function setFooterNormalMode() {
    if (footerTempTimer) clearTimeout(footerTempTimer);
    const footerBar = document.getElementById('footerBar');
    if (!footerBar) return;
    footerBar.classList.remove('temp-mode');
    let total = 0;
    for (let convId in discsMap) total += discsMap[convId].unread || 0;
    footerBar.innerHTML = `
        <div class="footer-left">
            <span class="app-name">LiveChat</span>
            <span class="version-badge">v1.0.0</span>
        </div>
        <div class="footer-center" id="footerClock">${getCurrentTime()}</div>
        <div class="footer-right" id="footerBadge" style="${total === 0 ? 'display:none;' : ''}">${total}</div>
    `;
    lastTempSenderId = null;
    startBarreClock();
}
function setFooterTempMode(senderId, senderName, message) {
    if (footerTempTimer) clearTimeout(footerTempTimer);
    lastTempSenderId = senderId;
    const footerBar = document.getElementById('footerBar');
    if (!footerBar) return;
    footerBar.classList.add('temp-mode');
    footerBar.innerHTML = `
        <div class="footer-left">
            <span class="temp-sender">${esc(senderName)}</span>
            <span class="temp-message"> : ${esc(message)}</span>
        </div>
        <div class="footer-right" id="footerBadge" style="display: none;">0</div>
    `;
    footerTempTimer = setTimeout(() => setFooterNormalMode(), 5000);
}
function startBarreListeners() {
    if (!me) return;
    db.ref('conversations').once('value', (snap) => {
        const convs = snap.val() || {};
        for (const convId in convs) {
            const conv = convs[convId];
            if (!conv.participants || !conv.participants.includes(me.uid)) continue;
            let isFirstMessage = true;
            const newMsgListener = db.ref(`messages/${convId}`).orderByChild('timestamp').limitToLast(1);
            newMsgListener.on('child_added', async (msgSnap) => {
                if (isFirstMessage) {
                    isFirstMessage = false;
                    return;
                }
                const msg = msgSnap.val();
                if (!msg) return;
                if (msg.senderId === me.uid) return;
                if (document.hidden) return;
                if (currentConvId === convId) return;
                let senderName = "Utilisateur";
                const userSnap = await db.ref(`users/${msg.senderId}`).once('value');
                const user = userSnap.val();
                if (user && user.username) senderName = user.username;
                setFooterTempMode(msg.senderId, senderName, msg.text);
                playNotifSound();
                vibrate();
            });
        }
    });
}

// ==================== FONCTIONS UTILES ====================
function esc(s) { return (s || '').replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[m]); }
function initial(n) { return (n || '?').charAt(0).toUpperCase(); }
function fmtTime(ts) { if (!ts) return ''; return new Date(ts).toLocaleTimeString('fr', { hour: '2-digit', minute: '2-digit' }); }
function fmtDate(ts) { if (!ts) return ''; const d = new Date(ts), t = new Date(), y = new Date(t); y.setDate(t.getDate() - 1); if (d.toDateString() === t.toDateString()) return fmtTime(ts); if (d.toDateString() === y.toDateString()) return 'Hier'; return d.toLocaleDateString('fr'); }
function dateSep(ts) { if (!ts) return ''; const d = new Date(ts), t = new Date(), y = new Date(t); y.setDate(t.getDate() - 1); if (d.toDateString() === t.toDateString()) return "Aujourd'hui"; if (d.toDateString() === y.toDateString()) return 'Hier'; return d.toLocaleDateString('fr', { day: 'numeric', month: 'long' }); }

// ==================== RÉGLAGES ET THÈMES ====================
function initToggles() {
    const toggles = [
        { id: 'toggleFindable', key: 'findable' },
        { id: 'toggleHidePresence', key: 'hidePresence' },
        { id: 'toggleDisableReadReceipt', key: 'disableReadReceipt' },
        { id: 'toggleDisableTyping', key: 'disableTyping' }
    ];
    toggles.forEach(t => {
        const el = document.getElementById(t.id);
        if (!el) return;
        el.addEventListener('click', async () => {
            const newValue = !el.classList.contains('active');
            el.classList.toggle('active', newValue);
            await saveSetting(t.key, newValue);
        });
    });
}
async function saveSetting(key, value) {
    if (!me) return;
    meSettings[key] = value;
    await db.ref(`users/${me.uid}/settings/${key}`).set(value);
    if (key === 'hidePresence') await db.ref(`users/${me.uid}/online`).set(!value);
}
function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme') || 'nuit';
    document.body.className = '';
    document.body.classList.add(`theme-${savedTheme}`);
    document.querySelectorAll('.theme-card').forEach(card => card.classList.toggle('active', card.dataset.theme === savedTheme));
}
function saveTheme(theme) { localStorage.setItem('theme', theme); applySavedTheme(); }

// ==================== AUTH & DÉMARRAGE (sans redirection auto) ====================
const savedUid = localStorage.getItem('livechat_uid');
if (!savedUid) {
    // Ne pas rediriger automatiquement → l'écran "Connectez-vous" reste affiché
    console.log("Utilisateur non connecté – écran fixe");
} else {
    me = { uid: savedUid, displayName: localStorage.getItem('livechat_username') || '', email: localStorage.getItem('livechat_email') || '' };
    loadUserProfile();
    loadCache();
    loadSoundSettings();
    applySavedTheme();
    initToggles();
    setFooterNormalMode();
    startBarreListeners();

    db.ref(`users/${savedUid}/settings`).once('value').then(snap => {
        const settings = snap.val() || {};
        meSettings.findable = settings.findable !== undefined ? settings.findable : true;
        meSettings.hidePresence = settings.hidePresence || false;
        meSettings.disableReadReceipt = settings.disableReadReceipt || false;
        meSettings.disableTyping = settings.disableTyping || false;
        document.getElementById('toggleFindable')?.classList.toggle('active', meSettings.findable);
        document.getElementById('toggleHidePresence')?.classList.toggle('active', meSettings.hidePresence);
        document.getElementById('toggleDisableReadReceipt')?.classList.toggle('active', meSettings.disableReadReceipt);
        document.getElementById('toggleDisableTyping')?.classList.toggle('active', meSettings.disableTyping);
        db.ref(`users/${me.uid}/online`).set(!meSettings.hidePresence);
        db.ref(`users/${me.uid}/online`).onDisconnect().set(false);
    });

    loadAllUsers();
    listenConversations();
}

function loadAllUsers() {
    db.ref('users').on('value', snap => {
        allUsers = snap.val() || {};
        saveUsersToCache();
    });
}

// ==================== CONVERSATIONS ====================
async function updateLastMsgStatus(convId) {
    if (!discsMap[convId]) return;
    const convRef = db.ref(`conversations/${convId}`);
    const convSnap = await convRef.once('value');
    const c = convSnap.val();
    if (!c) return;
    const otherId = c.participants.find(id => id !== me.uid);
    const lastMsgSnap = await db.ref(`messages/${convId}`).orderByChild('timestamp').limitToLast(1).once('value');
    let lastMsg = null;
    lastMsgSnap.forEach(msg => { lastMsg = msg.val(); });
    if (!lastMsg) return;
    const lastMsgSender = lastMsg.senderId;
    const lastMsgTime = lastMsg.timestamp;
    const lastReadMe = c.lastRead?.[me.uid] || 0;
    const lastReadOther = c.lastRead?.[otherId] || 0;
    let lastSentRead = false, lastReceivedRead = false;
    if (lastMsgSender === me.uid) lastSentRead = lastMsgTime <= lastReadOther;
    else lastReceivedRead = lastMsgTime <= lastReadMe;
    discsMap[convId].lastMsgSender = lastMsgSender;
    discsMap[convId].lastSentRead = lastSentRead;
    discsMap[convId].lastReceivedRead = lastReceivedRead;
    discsMap[convId].lastMsg = lastMsg.text;
    discsMap[convId].lastTime = lastMsg.timestamp;
    renderDiscs();
    saveDiscsToCache();
}
function listenConversations() {
    const convDbRef = db.ref('conversations');
    if (convListenerCb) convDbRef.off('value', convListenerCb);
    convListenerCb = convDbRef.on('value', async snap => {
        const convs = snap.val() || {};
        const newMap = {};
        for (const convId in convs) {
            const c = convs[convId];
            if (!Array.isArray(c.participants) || !c.participants.includes(me.uid)) continue;
            const otherId = c.participants.find(id => id !== me.uid);
            const u = allUsers[otherId] || {};
            const lastRead = c.lastRead?.[me.uid] || 0;
            let unread = 0;
            if (c.lastMessageTime && c.lastMessageTime > lastRead) {
                const msgsSnap = await db.ref(`messages/${convId}`).orderByChild('timestamp').startAfter(lastRead).once('value');
                msgsSnap.forEach(m => { if (m.val().senderId !== me.uid) unread++; });
            }
            let lastMsgSender = null, lastMsgText = c.lastMessage || 'Nouvelle conversation', lastMsgTime = c.lastMessageTime || c.createdAt || 0;
            let lastSentRead = false, lastReceivedRead = false;
            const lastMsgSnap = await db.ref(`messages/${convId}`).orderByChild('timestamp').limitToLast(1).once('value');
            let lastMsgObj = null;
            lastMsgSnap.forEach(msg => { lastMsgObj = msg.val(); });
            if (lastMsgObj) {
                lastMsgSender = lastMsgObj.senderId;
                lastMsgText = lastMsgObj.text;
                lastMsgTime = lastMsgObj.timestamp;
                const lastReadMe = c.lastRead?.[me.uid] || 0;
                const lastReadOther = c.lastRead?.[otherId] || 0;
                if (lastMsgSender === me.uid) lastSentRead = lastMsgTime <= lastReadOther;
                else lastReceivedRead = lastMsgTime <= lastReadMe;
            }
            newMap[convId] = {
                convId, otherId, name: u.username || u.email || '...',
                photo: u.photoURL || null, online: u.online || false,
                lastMsg: lastMsgText, lastTime: lastMsgTime, unread, isTyping: false,
                lastMsgSender, lastSentRead, lastReceivedRead
            };
            if (typingListeners[convId]) typingListeners[convId]();
            const typingRefItem = db.ref(`typing/${convId}/${otherId}`);
            const callback = typingRefItem.on('value', snap => {
                const isTyping = snap.val();
                if (newMap[convId]) newMap[convId].isTyping = isTyping || false;
                if (discsMap[convId]) { discsMap[convId].isTyping = isTyping || false; renderDiscs(); }
            });
            typingListeners[convId] = () => typingRefItem.off('value', callback);
            const lastReadOtherRef = db.ref(`conversations/${convId}/lastRead/${otherId}`);
            const lastReadMeRef = db.ref(`conversations/${convId}/lastRead/${me.uid}`);
            const updateCallback = () => updateLastMsgStatus(convId);
            lastReadOtherRef.on('value', updateCallback);
            lastReadMeRef.on('value', updateCallback);
            if (!typingListeners[`lastRead_${convId}`]) {
                typingListeners[`lastRead_${convId}`] = () => {
                    lastReadOtherRef.off('value', updateCallback);
                    lastReadMeRef.off('value', updateCallback);
                };
            }
        }
        discsMap = newMap;
        updateFooterTotalBadge();
        renderDiscs();
        saveDiscsToCache();
    });
}
function renderDiscs() {
    const container = document.getElementById('discList');
    if (!container) return;
    const q = document.getElementById('chatSearch')?.value.toLowerCase() || '';
    let arr = Object.values(discsMap).sort((a, b) => (b.lastTime || 0) - (a.lastTime || 0));
    if (q) arr = arr.filter(d => d.name.toLowerCase().includes(q) || d.lastMsg.toLowerCase().includes(q));
    if (!arr.length) {
        container.innerHTML = '<div class="empty"><i class="fas fa-comments"></i>Aucune discussion</div>';
        return;
    }
    container.innerHTML = arr.map(d => {
        let borderClass = '';
        if (d.lastMsgSender === me.uid) borderClass = d.lastSentRead ? 'sent-read' : 'sent-unread';
        else if (d.lastReceivedRead) borderClass = 'received-read';
        return `
        <div class="disc-card ${d.unread ? 'unread' : ''} ${borderClass}" data-conv-id="${d.convId}" data-other-id="${d.otherId}">
            <div class="avatar">
                ${d.photo ? `<img src="${esc(d.photo)}">` : initial(d.name)}
                ${(!meSettings.hidePresence && d.online) ? '<div class="dot"></div>' : ''}
            </div>
            <div class="disc-meta">
                <div class="disc-name">
                    ${esc(d.name)}
                    ${d.unread ? `<span class="badge-new">${d.unread}</span>` : ''}
                    ${(!meSettings.disableTyping && d.isTyping) ? '<span style="font-size:0.65rem; color:#5eead4; margin-left:6px;">✏️ écrit...</span>' : ''}
                </div>
                <div class="disc-last">${(!meSettings.disableTyping && d.isTyping) ? '...' : esc(d.lastMsg)}</div>
            </div>
            <div class="disc-time">${fmtDate(d.lastTime)}</div>
        </div>`;
    }).join('');
    container.querySelectorAll('.disc-card').forEach(el => {
        const convId = el.dataset.convId, otherId = el.dataset.otherId;
        let pressTimer = null;
        const startPress = () => { pressTimer = setTimeout(() => { pendingDeleteConvId = convId; document.getElementById('deleteModal').style.display = 'flex'; pressTimer = null; }, 500); };
        const cancelPress = () => { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } };
        el.addEventListener('click', (e) => { e.stopPropagation(); cancelPress(); openChat(convId, otherId); });
        el.addEventListener('mousedown', startPress);
        el.addEventListener('mouseup', cancelPress);
        el.addEventListener('mouseleave', cancelPress);
        el.addEventListener('touchstart', startPress, { passive: false });
        el.addEventListener('touchend', cancelPress);
        el.addEventListener('touchcancel', cancelPress);
    });
}
async function deleteConversation(convId) {
    if (!convId) return;
    await db.ref(`messages/${convId}`).remove();
    await db.ref(`conversations/${convId}`).remove();
    document.getElementById('deleteModal').style.display = 'none';
    pendingDeleteConvId = null;
    if (currentConvId === convId) closeChat();
}
async function startOrOpenChat(otherId) {
    for (const [cid, d] of Object.entries(discsMap)) if (d.otherId === otherId) { openChat(cid, otherId); return; }
    const snap = await db.ref('conversations').once('value');
    const convs = snap.val() || {};
    for (const cid in convs) {
        const c = convs[cid];
        if (c.participants?.includes(me.uid) && c.participants?.includes(otherId)) { openChat(cid, otherId); return; }
    }
    const ref = db.ref('conversations').push();
    await ref.set({ participants: [me.uid, otherId], createdAt: firebase.database.ServerValue.TIMESTAMP });
    openChat(ref.key, otherId);
}
function startTypingListener(convId, otherId) {
    if (typingRef) typingRef.off();
    typingRef = db.ref(`typing/${convId}/${otherId}`);
    typingRef.on('value', snap => {
        if (meSettings.disableTyping) return;
        const isTyping = snap.val();
        const typingIndicator = document.getElementById('typingIndicator');
        const onlineStatusSpan = document.getElementById('onlineStatus');
        if (isTyping) {
            if (typingIndicator) typingIndicator.textContent = '✏️ écrit...';
            if (onlineStatusSpan) onlineStatusSpan.style.display = 'none';
        } else {
            if (typingIndicator) typingIndicator.textContent = '';
            if (onlineStatusSpan) onlineStatusSpan.style.display = 'inline';
            setOnlineStatus(allUsers[otherId]?.online, otherId);
        }
    });
}
async function updateReadStatusOnly(convId) {
    if (meSettings.disableReadReceipt) return;
    if (!currentOtherUid) return;
    const snap = await db.ref(`conversations/${convId}/lastRead/${currentOtherUid}`).once('value');
    const otherLastRead = snap.val() || 0;
    document.querySelectorAll('.msg-row.sent').forEach(row => {
        const footer = row.querySelector('.message-footer');
        if (!footer) return;
        let statusSpan = footer.querySelector('.read-status');
        const timeEl = footer.querySelector('.msg-time');
        if (!timeEl) return;
        const msgTime = parseInt(timeEl.getAttribute('data-timestamp') || '0');
        if (!statusSpan) {
            statusSpan = document.createElement('span');
            statusSpan.className = 'read-status';
            footer.appendChild(statusSpan);
        }
        statusSpan.textContent = (msgTime && msgTime <= otherLastRead) ? '✔️✔️' : '✔️';
        statusSpan.className = msgTime <= otherLastRead ? 'read-status read' : 'read-status delivered';
    });
}
async function openChat(convId, otherId) {
    cleanupChat();
    currentConvId = convId;
    currentOtherUid = otherId;
    await db.ref(`conversations/${convId}/lastRead/${me.uid}`).set(firebase.database.ServerValue.TIMESTAMP);
    const u = allUsers[otherId] || {};
    const name = u.username || u.email || '...';
    const av = document.getElementById('chatAvatar');
    if (av) av.innerHTML = u.photoURL ? `<img src="${esc(u.photoURL)}">` : initial(name);
    document.getElementById('chatName').innerText = name;
    setOnlineStatus(u.online, otherId);
    onlineRef = db.ref(`users/${otherId}/online`);
    onlineRef.on('value', s => setOnlineStatus(s.val(), otherId));
    startTypingListener(convId, otherId);
    loadMessages(convId);
    if (lastReadListener) lastReadListener();
    lastReadListener = db.ref(`conversations/${convId}/lastRead/${otherId}`).on('value', () => {
        if (currentConvId === convId) updateReadStatusOnly(convId);
        updateLastMsgStatus(convId);
    });
    showView('discView');
}
function setOnlineStatus(isOnline, otherId) {
    const metaDiv = document.querySelector('.chat-header .chat-meta');
    if (metaDiv) {
        if (isOnline && !meSettings.hidePresence) metaDiv.classList.add('online');
        else metaDiv.classList.remove('online');
    }
    if (meSettings.disableReadReceipt) { document.getElementById('onlineStatus').innerText = ''; return; }
    const otherSettings = allUsers[otherId]?.settings || {};
    if (otherSettings.hidePresence) { document.getElementById('onlineStatus').innerText = ''; return; }
    const el = document.getElementById('onlineStatus');
    if (el) {
        el.innerText = isOnline ? '🟢 En ligne' : 'Hors ligne';
        el.className = isOnline ? 'online' : 'offline';
    }
}
function loadMessages(convId) {
    if (msgsRef) { msgsRef.off(); msgsRef = null; }
    const container = document.getElementById('msgsArea');
    if (!container) return;
    container.innerHTML = '<div class="loader-row"><div class="spin"></div> Chargement...</div>';
    msgsRef = db.ref(`messages/${convId}`).orderByChild('timestamp');
    msgsRef.on('value', async snap => {
        const data = snap.val();
        if (!data) { container.innerHTML = '<div class="empty"><i class="fas fa-comment-dots"></i>Commencez la conversation !</div>'; return; }
        if (currentConvId === convId && me) await db.ref(`conversations/${convId}/lastRead/${me.uid}`).set(firebase.database.ServerValue.TIMESTAMP);
        const otherLastReadSnap = await db.ref(`conversations/${convId}/lastRead/${currentOtherUid}`).once('value');
        const otherLastRead = otherLastReadSnap.val() || 0;
        const msgs = Object.entries(data).map(([id, m]) => ({ id, ...m })).sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
        let html = '', lastDate = '';
        const disableReceipt = meSettings.disableReadReceipt;
        msgs.forEach(m => {
            const isMe = m.senderId === me.uid;
            const ds = dateSep(m.timestamp);
            if (ds !== lastDate) { html += `<div class="date-sep">${ds}</div>`; lastDate = ds; }
            let statusHtml = '';
            if (isMe && !disableReceipt) statusHtml = (m.timestamp <= otherLastRead) ? '<span class="read-status read">✔️✔️</span>' : '<span class="read-status delivered">✔️</span>';
            html += `<div class="msg-row ${isMe ? 'sent' : 'recv'}">
                        <div class="bubble">${esc(m.text)}</div>
                        <div class="message-footer">
                            <div class="msg-time" data-timestamp="${m.timestamp || 0}">${fmtTime(m.timestamp)}</div>
                            ${statusHtml}
                        </div>
                    </div>`;
        });
        container.innerHTML = html;
        container.scrollTop = container.scrollHeight;
        updateLastMsgStatus(convId);
        if (currentConvId === convId && discsMap[convId]?.unread) { discsMap[convId].unread = 0; updateFooterTotalBadge(); renderDiscs(); }
    });
}
async function sendMessage() {
    const input = document.getElementById('msgInput');
    const text = input.value?.trim();
    if (!text || !currentConvId) return;
    input.value = '';
    input.style.height = 'auto';
    if (typingTimer) clearTimeout(typingTimer);
    if (!meSettings.disableTyping) await db.ref(`typing/${currentConvId}/${me.uid}`).remove();
    try {
        const newMsgRef = await db.ref(`messages/${currentConvId}`).push({
            senderId: me.uid, text, timestamp: firebase.database.ServerValue.TIMESTAMP
        });
        const newMsgSnap = await newMsgRef.once('value');
        const newMsg = newMsgSnap.val();
        await db.ref(`conversations/${currentConvId}`).update({ lastMessage: text, lastMessageTime: newMsg.timestamp });
        if (discsMap[currentConvId]) {
            discsMap[currentConvId].lastSentRead = false;
            discsMap[currentConvId].lastMsg = text;
            discsMap[currentConvId].lastTime = newMsg.timestamp;
            discsMap[currentConvId].lastMsgSender = me.uid;
            renderDiscs();
        }
        const snap = await db.ref(`conversations/${currentConvId}/lastRead/${currentOtherUid}`).once('value');
        const targetLastRead = snap.val() || 0;
        if (targetLastRead < Date.now() - 5000) sendPush(currentOtherUid, text);
    } catch (e) { console.error(e); }
}
function cleanupChat() {
    if (msgsRef) { msgsRef.off(); msgsRef = null; }
    if (onlineRef) { onlineRef.off(); onlineRef = null; }
    if (typingRef) { typingRef.off(); typingRef = null; }
    if (lastReadListener && currentConvId && currentOtherUid) {
        db.ref(`conversations/${currentConvId}/lastRead/${currentOtherUid}`).off('value', lastReadListener);
        lastReadListener = null;
    }
    if (typingTimer) clearTimeout(typingTimer);
    if (currentConvId && me && !meSettings.disableTyping) db.ref(`typing/${currentConvId}/${me.uid}`).remove();
    currentConvId = null;
    currentOtherUid = null;
}
function closeChat() {
    cleanupChat();
    showView('chatView');
}
function showView(viewId) {
    const currentActive = document.querySelector('.view.active');
    const nextView = document.getElementById(viewId);
    if (currentActive && currentActive.id === viewId) return;
    if (currentActive) {
        currentActive.classList.add('exit');
        setTimeout(() => {
            currentActive.classList.remove('exit');
            currentActive.classList.remove('active');
        }, 250);
    }
    if (nextView) nextView.classList.add('active');
    const bottomNav = document.getElementById('bottomNav');
    if (bottomNav) {
        if (viewId === 'discView' || viewId === 'settingsView' || viewId === 'findUserView') bottomNav.style.display = 'none';
        else bottomNav.style.display = 'flex';
    }
}
async function logout() {
    cleanupChat();
    if (me) await db.ref(`users/${me.uid}/online`).set(false);
    localStorage.removeItem('livechat_logged_in');
    localStorage.removeItem('livechat_uid');
    localStorage.removeItem('livechat_discsMap');
    localStorage.removeItem('livechat_allUsers');
    await auth.signOut();
    window.location.href = 'auth.html';
}

// ==================== VUE FIND USER ====================
let findCurrentMode = "username";
let findSearchTimeout = null;
function initFindUserView() {
    const findSearchInput = document.getElementById('findSearchInput');
    const findActionBtn = document.getElementById('findActionBtn');
    const findResultArea = document.getElementById('findResultArea');
    const modeBtns = document.querySelectorAll('#findUserView .mode-btn');
    if (!findSearchInput) return;
    findActionBtn.innerHTML = '<div class="spinner-small"></div>';
    findActionBtn.classList.add('loader');
    findActionBtn.disabled = true;
    let findClockInterval = null;
    function startFindClock() {
        if (findClockInterval) clearInterval(findClockInterval);
        const update = () => { const clockEl = document.getElementById('findFooterClock'); if (clockEl) clockEl.textContent = getCurrentTime(); };
        update();
        findClockInterval = setInterval(update, 1000);
    }
    startFindClock();
    modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            modeBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            findCurrentMode = btn.dataset.mode;
            if (findCurrentMode === 'username') {
                findSearchInput.placeholder = "Nom d'utilisateur (ex: Jean)";
                findActionBtn.innerHTML = '<div class="spinner-small"></div>';
                findActionBtn.classList.add('loader');
                findActionBtn.disabled = true;
                findSearchInput.value = "";
                findResultArea.innerHTML = "";
            } else {
                findSearchInput.placeholder = "Email exact (ex: jean@exemple.com)";
                findActionBtn.innerHTML = '<i class="fas fa-search"></i> Find';
                findActionBtn.classList.remove('loader');
                findActionBtn.disabled = false;
                findResultArea.innerHTML = "";
            }
        });
    });
    async function searchByUsername(query) {
        if (!query.trim()) { findResultArea.innerHTML = ""; return; }
        const lowerQuery = query.toLowerCase();
        const userId = me?.uid;
        const usersSnap = await db.ref('users').once('value');
        const users = usersSnap.val() || {};
        const results = [];
        for (const uid in users) {
            if (uid === userId) continue;
            const user = users[uid];
            const username = user.username || user.email || "";
            if (username.toLowerCase().includes(lowerQuery)) results.push({ uid, username, email: user.email, online: user.online || false });
        }
        if (results.length === 0) { findResultArea.innerHTML = `<div class="error-message"><i class="fas fa-user-slash"></i> Aucun utilisateur trouvé</div>`; return; }
        let html = `<div class="results-list">`;
        results.forEach(u => {
            const statusClass = u.online ? 'status-online' : 'status-offline';
            const statusText = u.online ? '🟢 En ligne' : '⚫ Hors ligne';
            const initial = u.username.charAt(0).toUpperCase();
            html += `<div class="result-item">
                        <div class="result-avatar">${esc(initial)}</div>
                        <div class="result-info">
                            <div class="result-name">${esc(u.username)}</div>
                            <div class="result-status"><span class="${statusClass}">${statusText}</span></div>
                        </div>
                        <button class="chat-mini-btn" data-uid="${u.uid}" data-name="${esc(u.username)}">Chat</button>
                    </div>`;
        });
        html += `</div>`;
        findResultArea.innerHTML = html;
        document.querySelectorAll('#findResultArea .chat-mini-btn').forEach(btn => { btn.addEventListener('click', () => startOrOpenChat(btn.dataset.uid)); });
    }
    async function searchByEmail(email) {
        if (!email.trim()) { findResultArea.innerHTML = `<div class="error-message">Veuillez entrer un email</div>`; return; }
        const usersSnap = await db.ref('users').once('value');
        const users = usersSnap.val() || {};
        let foundUser = null;
        for (const uid in users) { const user = users[uid]; if (user.email && user.email.toLowerCase() === email.toLowerCase()) { foundUser = { uid, ...user }; break; } }
        if (!foundUser) { findResultArea.innerHTML = `<div class="error-message"><i class="fas fa-user-slash"></i> Aucun utilisateur ne correspond à cet email</div>`; return; }
        const statusClass = foundUser.online ? 'status-online' : 'status-offline';
        const statusText = foundUser.online ? '🟢 En ligne' : '⚫ Hors ligne';
        const initial = (foundUser.username || foundUser.email).charAt(0).toUpperCase();
        findResultArea.innerHTML = `<div class="profile-card">
                                        <div class="profile-avatar">${esc(initial)}</div>
                                        <div class="profile-info">
                                            <div class="profile-name">${esc(foundUser.username || foundUser.email)}</div>
                                            <div class="profile-email">${esc(foundUser.email)}</div>
                                            <div class="profile-status ${statusClass}">${statusText}</div>
                                        </div>
                                        <button class="chat-btn" data-uid="${foundUser.uid}" data-name="${esc(foundUser.username || foundUser.email)}">Chat</button>
                                    </div>`;
        const chatBtn = findResultArea.querySelector('.chat-btn');
        if (chatBtn) chatBtn.addEventListener('click', () => startOrOpenChat(chatBtn.dataset.uid));
    }
    findSearchInput.addEventListener('input', (e) => {
        if (findCurrentMode === 'username') {
            if (findSearchTimeout) clearTimeout(findSearchTimeout);
            findSearchTimeout = setTimeout(() => searchByUsername(e.target.value), 200);
        }
    });
    findActionBtn.addEventListener('click', () => {
        if (findCurrentMode === 'email') searchByEmail(findSearchInput.value);
        else searchByUsername(findSearchInput.value);
    });
}

// ==================== NAVIGATION & ÉVÉNEMENTS ====================
document.getElementById('plusBtn')?.addEventListener('click', () => { showView('findUserView'); setTimeout(() => initFindUserView(), 50); });
document.getElementById('backFromFindBtn')?.addEventListener('click', () => showView('chatView'));
document.getElementById('settingsBtnHeader')?.addEventListener('click', () => showView('settingsView'));
document.getElementById('backFromSettingsBtn')?.addEventListener('click', () => showView('chatView'));
document.getElementById('backBtn')?.addEventListener('click', closeChat);
document.getElementById('saveProfileBtn')?.addEventListener('click', () => {
    const newUsername = document.getElementById('usernameInput')?.value.trim();
    if (newUsername && me) {
        localStorage.setItem('username', newUsername);
        document.getElementById('avatarInitial').innerText = newUsername.charAt(0).toUpperCase();
        db.ref(`users/${me.uid}/username`).set(newUsername);
        alert('Profil mis à jour !');
    }
});
document.querySelectorAll('.theme-card').forEach(card => card.addEventListener('click', () => saveTheme(card.dataset.theme)));
const volumeSlider = document.getElementById('volumeSlider');
const vibrationSlider = document.getElementById('vibrationSlider');
if (volumeSlider) volumeSlider.addEventListener('input', (e) => saveVolume(parseInt(e.target.value)));
if (vibrationSlider) vibrationSlider.addEventListener('input', (e) => saveVibration(parseInt(e.target.value)));
const logoutOverlay = document.getElementById('confirmLogoutOverlay');
document.getElementById('logoutBtn')?.addEventListener('click', () => { if (logoutOverlay) logoutOverlay.style.display = 'flex'; });
document.getElementById('confirmLogoutBtn')?.addEventListener('click', async () => { if (logoutOverlay) logoutOverlay.style.display = 'none'; await logout(); });
document.getElementById('cancelLogoutBtn')?.addEventListener('click', () => { if (logoutOverlay) logoutOverlay.style.display = 'none'; });
const deleteModal = document.getElementById('deleteModal');
document.getElementById('confirmDeleteBtn')?.addEventListener('click', () => { if (pendingDeleteConvId) deleteConversation(pendingDeleteConvId); });
document.getElementById('cancelDeleteBtn')?.addEventListener('click', () => { if (deleteModal) deleteModal.style.display = 'none'; pendingDeleteConvId = null; });
document.getElementById('chatSearch')?.addEventListener('input', () => renderDiscs());
document.getElementById('sendBtn')?.addEventListener('click', sendMessage);
const footerBar = document.getElementById('footerBar');
if (footerBar) {
    footerBar.addEventListener('click', async () => {
        if (lastTempSenderId && currentConvId !== lastTempSenderId) {
            let targetConvId = null;
            for (const [cid, disc] of Object.entries(discsMap)) if (disc.otherId === lastTempSenderId) { targetConvId = cid; break; }
            if (targetConvId) openChat(targetConvId, lastTempSenderId);
            else startOrOpenChat(lastTempSenderId);
        }
    });
}
const msgInputField = document.getElementById('msgInput');
msgInputField?.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 90) + 'px';
    if (!currentConvId || !me || meSettings.disableTyping) return;
    if (typingTimer) clearTimeout(typingTimer);
    db.ref(`typing/${currentConvId}/${me.uid}`).set(true);
    typingTimer = setTimeout(() => db.ref(`typing/${currentConvId}/${me.uid}`).remove(), 2000);
});