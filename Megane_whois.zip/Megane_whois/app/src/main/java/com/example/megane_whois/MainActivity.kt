package com.example.megane_whois

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationManagerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val notificationPermissionCode = 101
    private val TAG = "MeganeWhois"
    private var directUserId: String? = null
    private val minSplashTime = 1000L // 1 seconde minimum

    override fun onCreate(savedInstanceState: Bundle?) {
        // 🔥 Appliquer le thème Splash AVANT super.onCreate
        setTheme(com.example.megane_whois.R.style.Theme_Splash)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 🔥 Garde le fond du splash natif jusqu'à chargement de splash.html
        window.setBackgroundDrawableResource(R.drawable.splash_background)

        // ── Permission notifications (Android 13+) ──────────────
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    notificationPermissionCode
                )
            }
        }

        // ── Canal de notification (Android 8+) ──────────────────
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "livechat_channel",
                "Megane_whois",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications des messages Megane_whois"
                enableLights(true)
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }

        // ── Lire l'intent (clic sur notification) ───────────────
        directUserId = intent.getStringExtra(
            MyFirebaseMessagingService.EXTRA_SENDER_UID
        )

        // Supprimer UNIQUEMENT la notification sur laquelle on a cliqué
        if (directUserId != null) {
            val notifId = MyFirebaseMessagingService.notifIdForUser(directUserId!!)
            NotificationManagerCompat.from(this).cancel(notifId)
            Log.d(TAG, "📬 Notif supprimée pour $directUserId")
        }

        // ── Configuration WebView optimisée ─────────────────────
        webView = findViewById(R.id.webview)
        webView.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                setRenderPriority(WebSettings.RenderPriority.HIGH)
            }
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            setDrawingCacheEnabled(false)

            webViewClient = object : WebViewClient() {
                private val startTime = System.currentTimeMillis()

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)

                    val elapsed = System.currentTimeMillis() - startTime
                    val remaining = minSplashTime - elapsed

                    if (remaining > 0) {
                        // Attendre la fin du temps minimum (1 seconde)
                        Handler(Looper.getMainLooper()).postDelayed({
                            window.setBackgroundDrawable(null)
                            Log.d(TAG, "✅ Splash natif masqué après ${minSplashTime}ms")
                        }, remaining)
                    } else {
                        window.setBackgroundDrawable(null)
                        Log.d(TAG, "✅ Splash natif masqué immédiatement")
                    }

                    directUserId?.let { uid ->
                        openChatDirectly(uid)
                        directUserId = null
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    errorCode: Int,
                    description: String?,
                    failingUrl: String?
                ) {
                    super.onReceivedError(view, errorCode, description, failingUrl)
                    Log.e(TAG, "Erreur WebView: $description")
                    // En cas d'erreur, on cache quand même le splash
                    window.setBackgroundDrawable(null)
                }
            }
            addJavascriptInterface(AndroidBridge(this@MainActivity), "AndroidBridge")
        }

        // Charger splash.html d'abord
        val url = if (directUserId != null) {
            "file:///android_asset/splash.html?openChat=$directUserId"
        } else {
            "file:///android_asset/splash.html"
        }
        webView.loadUrl(url)

        // ── Bouton retour ────────────────────────────────────────
        onBackPressedDispatcher.addCallback(
            this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        finish()
                    }
                }
            }
        )
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val senderUid = intent.getStringExtra(
            MyFirebaseMessagingService.EXTRA_SENDER_UID
        )
        if (senderUid != null) {
            Log.d(TAG, "📬 onNewIntent — expéditeur: $senderUid")
            val notifId = MyFirebaseMessagingService.notifIdForUser(senderUid)
            NotificationManagerCompat.from(this).cancel(notifId)
            openChatDirectly(senderUid)
        }
    }

    private fun openChatDirectly(senderUid: String) {
        Log.d(TAG, "🚀 Ouverture directe discussion pour: $senderUid")
        webView.post {
            webView.evaluateJavascript(
                "if(typeof window.openChatDirectly === 'function') window.openChatDirectly('$senderUid'); else if(typeof startOrOpenChat === 'function') startOrOpenChat('$senderUid');",
                null
            )
        }
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.resumeTimers()
        AppState.isAppInForeground = true
        Log.d(TAG, "▶️ App au premier plan")
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
        webView.pauseTimers()
        AppState.isAppInForeground = false
        Log.d(TAG, "⏸️ App en arrière-plan")
    }

    override fun onDestroy() {
        webView.apply {
            clearHistory()
            clearCache(true)
            loadUrl("about:blank")
            removeAllViews()
            destroy()
        }
        AppState.isAppInForeground = false
        super.onDestroy()
    }
}