package com.example.megane_whois

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.*
import android.media.RingtoneManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        const val EXTRA_SENDER_UID = "senderUid"
        private const val TAG = "FCMService"
        private const val CHANNEL_ID = "livechat_channel"

        // Map userId → données (messages + nom)
        // Chaque userId a son propre ID de notification
        private val senderDataMap = mutableMapOf<String, SenderData>()
        private val lock = Any()
        private var lastSoundTime = 0L

        fun clearAllData() {
            synchronized(lock) { senderDataMap.clear() }
        }

        // ID de notification unique par expéditeur
        // On utilise un hash stable du userId
        fun notifIdForUser(userId: String): Int {
            return userId.hashCode().let { if (it < 0) -it else it } % 10000 + 2000
        }

        data class SenderData(
            val userId: String,
            val name: String,
            val messages: MutableList<Pair<String, Long>> = mutableListOf()
        )
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d(TAG, "📩 Message FCM reçu")

        if (AppState.isAppInForeground) {
            Log.d(TAG, "📱 App au premier plan → ignoré")
            return
        }

        val data      = remoteMessage.data
        val userId    = data["userId"]      ?: return
        val userName  = data["userName"]    ?: "Utilisateur"
        val msgText   = data["messageText"] ?: return
        val timestamp = System.currentTimeMillis()

        synchronized(lock) {
            val sender = senderDataMap.getOrPut(userId) {
                SenderData(userId, userName)
            }
            sender.messages.add(Pair(msgText, timestamp))
        }

        val now = SystemClock.elapsedRealtime()
        val playSound = (now - lastSoundTime) > 10_000L
        if (playSound) lastSoundTime = now

        // Afficher/mettre à jour la notification de CET expéditeur uniquement
        showNotificationForUser(userId, playSound)
    }

    private fun showNotificationForUser(userId: String, playSound: Boolean) {
        val senderData = synchronized(lock) { senderDataMap[userId] } ?: return
        val notifId    = notifIdForUser(userId)
        val totalMsgs  = senderData.messages.size

        // ── Avatar circulaire (cercle bleu + initiale blanche) ──
        val largeIcon = buildAvatarBitmap(senderData.name)

        // ── Intent → ouvre directement la conv de cet expéditeur ──
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_SENDER_UID, userId) // ✅ MainActivity lira ceci
        }
        val pendingIntent = PendingIntent.getActivity(
            this, notifId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                        PendingIntent.FLAG_IMMUTABLE else 0
        )

        // ── Heure du dernier message ────────────────────────────
        val lastTime = senderData.messages.lastOrNull()?.second
            ?: System.currentTimeMillis()
        val timeStr = android.text.format.DateFormat.format("HH:mm", lastTime).toString()

        // ── Titre : "Ivan · 3 messages · 14:30" ────────────────
        val title = "${senderData.name}  ·  $totalMsgs message${if (totalMsgs > 1) "s" else ""}  ·  $timeStr"

        // ── Texte replié : dernier message ──────────────────────
        val collapsedText = senderData.messages.last().first.let {
            if (it.length > 60) it.take(60) + "…" else it
        }

        // ── InboxStyle déplié : tous les messages ───────────────
        val inboxStyle = NotificationCompat.InboxStyle()
            .setBigContentTitle(title)

        // Afficher max 6 messages (les plus récents)
        val displayMsgs = if (senderData.messages.size > 6) {
            val hidden = senderData.messages.size - 6
            inboxStyle.setSummaryText("+$hidden messages précédents")
            senderData.messages.takeLast(6)
        } else {
            senderData.messages.toList()
        }

        displayMsgs.forEach { (text, _) ->
            inboxStyle.addLine(if (text.length > 60) text.take(60) + "…" else text)
        }

        // ── Son / vibration ─────────────────────────────────────
        val soundUri = if (playSound)
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        else null

        // ── Construction ─────────────────────────────────────────
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(Color.parseColor("#3b8bff"))
            .setLargeIcon(largeIcon)             // ✅ avatar circulaire à droite
            .setContentTitle(title)
            .setContentText(collapsedText)
            .setStyle(inboxStyle)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setNumber(totalMsgs)
            .setOnlyAlertOnce(!playSound)        // son/vibration seulement si nouveau

        if (playSound && soundUri != null) {
            builder.setSound(soundUri)
            builder.setVibrate(longArrayOf(0, 200, 100, 200))
        } else {
            builder.setSound(null)
            builder.setVibrate(null)
        }

        try {
            NotificationManagerCompat.from(this).notify(notifId, builder.build())
            Log.d(TAG, "✅ Notif #$notifId pour ${senderData.name} — $totalMsgs msg(s)")
        } catch (e: SecurityException) {
            Log.e(TAG, "❌ Permission refusée: ${e.message}")
        }
    }

    // ── Génère un bitmap circulaire bleu avec l'initiale ────────
    private fun buildAvatarBitmap(name: String): Bitmap {
        val size   = 128
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Fond circulaire bleu
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#3b8bff")
        }
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, bgPaint)

        // Initiale blanche centrée
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color     = Color.WHITE
            textSize  = size * 0.45f
            typeface  = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val initial = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        val textY   = size / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(initial, size / 2f, textY, textPaint)

        return bitmap
    }

    override fun onNewToken(token: String) {
        Log.d(TAG, "🔄 Nouveau token FCM")
        val user = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseDatabase.getInstance()
            .getReference("fcmTokens")
            .child(user.uid)
            .child(token)
            .setValue(true)
            .addOnSuccessListener { Log.d(TAG, "✅ Token enregistré") }
            .addOnFailureListener { e -> Log.e(TAG, "❌ Erreur: ${e.message}") }
    }
}