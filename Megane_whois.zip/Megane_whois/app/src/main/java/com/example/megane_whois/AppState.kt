package com.example.megane_whois

object AppState {
    var isAppInForeground = false
}