package com.example.megane_whois

import android.content.Context
import android.util.Log
import android.webkit.JavascriptInterface
import com.google.firebase.messaging.FirebaseMessaging

class AndroidBridge(private val context: Context) {

    private val TAG = "AndroidBridge"

    @JavascriptInterface
    fun onUserLoggedIn(userId: String) {
        Log.d(TAG, "📲 onUserLoggedIn — userId: $userId")
        if (userId.isBlank()) {
            Log.e(TAG, "❌ userId vide, abandon")
            return
        }
        if (context is MainActivity) {
            context.setPendingUserId(userId)
        }
        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                Log.d(TAG, "✅ Token FCM obtenu: $token")
                saveTokenToDatabase(userId, token)
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "❌ Erreur token FCM: ${e.message}")
            }
    }

    @JavascriptInterface
    fun openGallery() {
        Log.d(TAG, "📷 Ouverture galerie")
        try {
            if (context is MainActivity) {
                context.startGalleryForResult()
            } else {
                Log.e(TAG, "❌ Context n'est pas une MainActivity")
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Erreur ouverture galerie: ${e.message}")
        }
    }

    @JavascriptInterface
    fun setCurrentUserId(userId: String) {
        Log.d(TAG, "👤 UID reçu de la WebView: $userId")
        if (context is MainActivity) {
            context.setPendingUserId(userId)
        }
    }

    @JavascriptInterface
    fun uploadAvatarFromBase64(base64: String, userId: String) {
        Log.d(TAG, "⬆️ Upload avatar depuis base64 pour userId: $userId")
        if (context is MainActivity) {
            context.uploadAvatarFromBase64(base64, userId)
        } else {
            Log.e(TAG, "❌ Context n'est pas une MainActivity")
        }
    }

    private fun saveTokenToDatabase(userId: String, token: String) {
        val db = com.google.firebase.database.FirebaseDatabase.getInstance()
        db.getReference("fcmTokens")
            .child(userId)
            .child(token)
            .setValue(true)
            .addOnSuccessListener {
                Log.d(TAG, "✅ Token enregistré dans Firebase !")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "❌ Erreur Firebase: ${e.message}")
            }
    }
}