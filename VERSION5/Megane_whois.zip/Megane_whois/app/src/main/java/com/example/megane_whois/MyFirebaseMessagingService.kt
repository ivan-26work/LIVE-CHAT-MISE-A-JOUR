package com.example.megane_whois

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.*
import android.media.RingtoneManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        const val EXTRA_SENDER_UID = "senderUid"
        private const val TAG = "FCMService"
        private const val CHANNEL_ID = "livechat_channel"

        private val senderDataMap = mutableMapOf<String, SenderData>()
        private val lock = Any()
        private var lastSoundTime = 0L
        private val avatarCache = mutableMapOf<String, Bitmap>()

        fun clearAllData() {
            synchronized(lock) { senderDataMap.clear() }
        }

        fun notifIdForUser(userId: String): Int {
            return userId.hashCode().let { if (it < 0) -it else it } % 10000 + 2000
        }

        data class SenderData(
            val userId: String,
            val name: String,
            val avatarUrl: String = "",
            val messages: MutableList<Pair<String, Long>> = mutableListOf()
        )
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d(TAG, "📩 Message FCM reçu")

        if (AppState.isAppInForeground) {
            Log.d(TAG, "📱 App au premier plan → ignoré")
            return
        }

        val data = remoteMessage.data
        val userId = data["userId"] ?: return
        val userName = data["userName"] ?: "Utilisateur"
        val userAvatar = data["userAvatar"] ?: ""
        val msgText = data["messageText"] ?: return
        val timestamp = System.currentTimeMillis()

        synchronized(lock) {
            val sender = senderDataMap.getOrPut(userId) {
                SenderData(userId, userName, userAvatar)
            }
            // Si l'avatar n'était pas présent dans le premier message, on le met à jour
            if (sender.avatarUrl.isEmpty() && userAvatar.isNotEmpty()) {
                senderDataMap[userId] = sender.copy(avatarUrl = userAvatar)
            }
            sender.messages.add(Pair(msgText, timestamp))
        }

        val now = SystemClock.elapsedRealtime()
        val playSound = (now - lastSoundTime) > 10_000L
        if (playSound) lastSoundTime = now

        showNotificationForUser(userId, playSound)
    }

    private fun showNotificationForUser(userId: String, playSound: Boolean) {
        val senderData = synchronized(lock) { senderDataMap[userId] } ?: return
        val notifId = notifIdForUser(userId)
        val totalMsgs = senderData.messages.size

        // 🔥 Avatar : depuis URL si disponible, sinon cercle + initiale
        val largeIcon = if (senderData.avatarUrl.isNotEmpty()) {
            loadBitmapFromUrl(senderData.avatarUrl) ?: buildAvatarBitmap(senderData.name)
        } else {
            buildAvatarBitmap(senderData.name)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_SENDER_UID, userId)
        }
        val pendingIntent = PendingIntent.getActivity(
            this, notifId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                        PendingIntent.FLAG_IMMUTABLE else 0
        )

        val lastTime = senderData.messages.lastOrNull()?.second ?: System.currentTimeMillis()
        val timeStr = android.text.format.DateFormat.format("HH:mm", lastTime).toString()
        val title = "${senderData.name}  ·  $totalMsgs message${if (totalMsgs > 1) "s" else ""}  ·  $timeStr"
        val collapsedText = senderData.messages.last().first.let {
            if (it.length > 60) it.take(60) + "…" else it
        }

        val inboxStyle = NotificationCompat.InboxStyle().setBigContentTitle(title)
        val displayMsgs = if (senderData.messages.size > 6) {
            val hidden = senderData.messages.size - 6
            inboxStyle.setSummaryText("+$hidden messages précédents")
            senderData.messages.takeLast(6)
        } else {
            senderData.messages.toList()
        }

        displayMsgs.forEach { (text, _) ->
            inboxStyle.addLine(if (text.length > 60) text.take(60) + "…" else text)
        }

        val soundUri = if (playSound)
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        else null

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(Color.parseColor("#3b8bff"))
            .setLargeIcon(largeIcon)
            .setContentTitle(title)
            .setContentText(collapsedText)
            .setStyle(inboxStyle)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setNumber(totalMsgs)
            .setOnlyAlertOnce(!playSound)

        if (playSound && soundUri != null) {
            builder.setSound(soundUri)
            builder.setVibrate(longArrayOf(0, 200, 100, 200))
        } else {
            builder.setSound(null)
            builder.setVibrate(null)
        }

        try {
            NotificationManagerCompat.from(this).notify(notifId, builder.build())
            Log.d(TAG, "✅ Notif #$notifId pour ${senderData.name} — $totalMsgs msg(s)")
        } catch (e: SecurityException) {
            Log.e(TAG, "❌ Permission refusée: ${e.message}")
        }
    }

    private fun buildAvatarBitmap(name: String): Bitmap {
        val size = 128
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#3b8bff")
        }
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, bgPaint)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = size * 0.45f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val initial = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        val textY = size / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(initial, size / 2f, textY, textPaint)
        return bitmap
    }

    private fun loadBitmapFromUrl(urlString: String): Bitmap? {
        // Vérifier le cache
        avatarCache[urlString]?.let { return it }

        return try {
            val url = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection
            connection.doInput = true
            connection.connect()
            val input: InputStream = connection.inputStream
            val bitmap = BitmapFactory.decodeStream(input)
            input.close()
            connection.disconnect()
            // Mettre en cache
            bitmap?.let { avatarCache[urlString] = it }
            bitmap
        } catch (e: Exception) {
            Log.e(TAG, "❌ Erreur chargement avatar: ${e.message}")
            null
        }
    }

    override fun onNewToken(token: String) {
        Log.d(TAG, "🔄 Nouveau token FCM")
        val user = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseDatabase.getInstance()
            .getReference("fcmTokens")
            .child(user.uid)
            .child(token)
            .setValue(true)
            .addOnSuccessListener { Log.d(TAG, "✅ Token enregistré") }
            .addOnFailureListener { e -> Log.e(TAG, "❌ Erreur: ${e.message}") }
    }
}