package com.example.megane_whois

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val notificationPermissionCode = 101
    private val TAG = "MeganeWhois"
    private var directUserId: String? = null
    private val minSplashTime = 1000L
    private var pendingUserId: String? = null

    // Gestionnaire de résultat pour la galerie
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            val selectedImageUri = data?.data
            if (selectedImageUri != null) {
                Log.d(TAG, "📸 Image sélectionnée: $selectedImageUri")
                uploadAvatarFromUri(selectedImageUri)
            } else {
                Log.e(TAG, "❌ URI null")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(com.example.megane_whois.R.style.Theme_Splash)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.setBackgroundDrawableResource(R.drawable.splash_background)

        // Permission notifications (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    notificationPermissionCode
                )
            }
        }

        // Canal de notification (Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "livechat_channel",
                "Megane_whois",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications des messages Megane_whois"
                enableLights(true)
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }

        // Lire l'intent (clic sur notification)
        directUserId = intent.getStringExtra(
            MyFirebaseMessagingService.EXTRA_SENDER_UID
        )

        if (directUserId != null) {
            val notifId = MyFirebaseMessagingService.notifIdForUser(directUserId!!)
            NotificationManagerCompat.from(this).cancel(notifId)
            Log.d(TAG, "📬 Notif supprimée pour $directUserId")
        }

        // Configuration WebView
        webView = findViewById(R.id.webview)
        webView.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
            }
            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            webViewClient = object : WebViewClient() {
                private val startTime = System.currentTimeMillis()

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)

                    val elapsed = System.currentTimeMillis() - startTime
                    val remaining = minSplashTime - elapsed

                    if (remaining > 0) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            window.setBackgroundDrawable(null)
                            Log.d(TAG, "✅ Splash natif masqué après ${minSplashTime}ms")
                        }, remaining)
                    } else {
                        window.setBackgroundDrawable(null)
                        Log.d(TAG, "✅ Splash natif masqué immédiatement")
                    }

                    directUserId?.let { uid ->
                        openChatDirectly(uid)
                        directUserId = null
                    }
                }

                @Suppress("DEPRECATION")
                override fun onReceivedError(
                    view: WebView?,
                    errorCode: Int,
                    description: String?,
                    failingUrl: String?
                ) {
                    super.onReceivedError(view, errorCode, description, failingUrl)
                    Log.e(TAG, "Erreur WebView: $description")
                    window.setBackgroundDrawable(null)
                }
            }
            addJavascriptInterface(AndroidBridge(this@MainActivity), "AndroidBridge")
        }

        val url = if (directUserId != null) {
            "file:///android_asset/splash.html?openChat=$directUserId"
        } else {
            "file:///android_asset/splash.html"
        }
        webView.loadUrl(url)

        onBackPressedDispatcher.addCallback(
            this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        finish()
                    }
                }
            }
        )
    }

    fun startGalleryForResult() {
        try {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            galleryLauncher.launch(intent)
            Log.d(TAG, "📷 Galerie ouverte")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Erreur ouverture galerie: ${e.message}")
        }
    }

    fun setPendingUserId(userId: String) {
        pendingUserId = userId
        Log.d(TAG, "👤 UID reçu de la WebView: $userId")
    }

    fun uploadAvatarFromBase64(base64: String, userId: String) {
        Log.d(TAG, "⬆️ Upload avatar depuis base64 pour userId: $userId")

        try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val storageRef = FirebaseStorage.getInstance().reference
            val avatarRef = storageRef.child("avatars/${userId}.jpg")

            val metadata = StorageMetadata.Builder()
                .setContentType("image/jpeg")
                .build()

            avatarRef.putBytes(bytes, metadata)
                .addOnSuccessListener {
                    avatarRef.downloadUrl.addOnSuccessListener { downloadUri ->
                        Log.d(TAG, "✅ Avatar uploadé: $downloadUri")
                        webView.evaluateJavascript(
                            "if(typeof window.onAvatarUploadComplete === 'function') window.onAvatarUploadComplete('${downloadUri.toString()}');",
                            null
                        )
                    }.addOnFailureListener { e ->
                        Log.e(TAG, "❌ Erreur récupération URL: ${e.message}")
                        webView.evaluateJavascript(
                            "if(typeof window.onAvatarUploadError === 'function') window.onAvatarUploadError('${e.message}');",
                            null
                        )
                    }
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "❌ Erreur upload: ${e.message}")
                    webView.evaluateJavascript(
                        "if(typeof window.onAvatarUploadError === 'function') window.onAvatarUploadError('${e.message}');",
                        null
                    )
                }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Exception: ${e.message}")
            webView.evaluateJavascript(
                "if(typeof window.onAvatarUploadError === 'function') window.onAvatarUploadError('${e.message}');",
                null
            )
        }
    }

    private fun uploadAvatarFromUri(uri: Uri) {
        Log.d(TAG, "⬆️ Upload avatar depuis URI: $uri")

        val currentUserUid = pendingUserId
        if (currentUserUid == null) {
            Log.e(TAG, "❌ pendingUserId est null")
            webView.evaluateJavascript(
                "if(typeof window.onAvatarUploadError === 'function') window.onAvatarUploadError('Utilisateur non connecté');",
                null
            )
            return
        }

        try {
            val storageRef = FirebaseStorage.getInstance().reference
            val avatarRef = storageRef.child("avatars/${currentUserUid}.jpg")

            val metadata = StorageMetadata.Builder()
                .setContentType("image/jpeg")
                .build()

            contentResolver.openInputStream(uri)?.use { inputStream ->
                val bytes = inputStream.readBytes()

                avatarRef.putBytes(bytes, metadata)
                    .addOnSuccessListener {
                        avatarRef.downloadUrl.addOnSuccessListener { downloadUri ->
                            Log.d(TAG, "✅ Avatar uploadé: $downloadUri")
                            webView.evaluateJavascript(
                                "if(typeof window.onAvatarUploadComplete === 'function') window.onAvatarUploadComplete('${downloadUri.toString()}');",
                                null
                            )
                        }.addOnFailureListener { e ->
                            Log.e(TAG, "❌ Erreur get URL: ${e.message}")
                            webView.evaluateJavascript(
                                "if(typeof window.onAvatarUploadError === 'function') window.onAvatarUploadError('${e.message}');",
                                null
                            )
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.e(TAG, "❌ Erreur upload: ${e.message}")
                        webView.evaluateJavascript(
                            "if(typeof window.onAvatarUploadError === 'function') window.onAvatarUploadError('${e.message}');",
                            null
                        )
                    }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Exception lecture fichier: ${e.message}")
            webView.evaluateJavascript(
                "if(typeof window.onAvatarUploadError === 'function') window.onAvatarUploadError('Erreur lecture image');",
                null
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val senderUid = intent.getStringExtra(
            MyFirebaseMessagingService.EXTRA_SENDER_UID
        )
        if (senderUid != null) {
            Log.d(TAG, "📬 onNewIntent — expéditeur: $senderUid")
            val notifId = MyFirebaseMessagingService.notifIdForUser(senderUid)
            NotificationManagerCompat.from(this).cancel(notifId)
            openChatDirectly(senderUid)
        }
    }

    private fun openChatDirectly(senderUid: String) {
        Log.d(TAG, "🚀 Ouverture directe discussion pour: $senderUid")
        webView.post {
            webView.evaluateJavascript(
                "if(typeof window.openChatDirectly === 'function') window.openChatDirectly('$senderUid'); else if(typeof startOrOpenChat === 'function') startOrOpenChat('$senderUid');",
                null
            )
        }
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.resumeTimers()
        AppState.isAppInForeground = true
        Log.d(TAG, "▶️ App au premier plan")
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
        webView.pauseTimers()
        AppState.isAppInForeground = false
        Log.d(TAG, "⏸️ App en arrière-plan")
    }

    override fun onDestroy() {
        webView.apply {
            clearHistory()
            clearCache(true)
            loadUrl("about:blank")
            removeAllViews()
            destroy()
        }
        AppState.isAppInForeground = false
        super.onDestroy()
    }
}